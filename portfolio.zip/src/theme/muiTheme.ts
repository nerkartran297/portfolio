import { createTheme } from "@mui/material/styles";
import type { ThemeMode } from "../store/themeSlice";

// Helper to get CSS variable value with fallback
const getCSSVar = (varName: string, fallback: string): string => {
  if (typeof window !== "undefined") {
    const value = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
    return value || fallback;
  }
  return fallback;
};

export const createMuiTheme = (mode: ThemeMode) => {
  // Read from CSS variables with fallbacks
  const bg = getCSSVar("--bg", mode === "dark" ? "6, 10, 22" : "238, 241, 246");
  const card = getCSSVar("--card", mode === "dark" ? "10, 22, 48" : "255, 255, 255");
  const text = getCSSVar("--text", mode === "dark" ? "235, 242, 255" : "20, 22, 28");
  const textMuted = getCSSVar("--text-muted", mode === "dark" ? "170, 190, 220" : "80, 85, 100");
  const hairline = getCSSVar("--hairline", mode === "dark" ? "255, 255, 255" : "0, 0, 0");
  const hairlineOpacity = getCSSVar("--hairline-opacity", mode === "dark" ? "0.12" : "0.08");
  const shadow = getCSSVar("--shadow", "0, 0, 0");
  const shadowOpacity = getCSSVar("--shadow-opacity", mode === "dark" ? "0.35" : "0.08");
  const accentBlue = getCSSVar("--accent-blue", "54, 120, 255");
  const accentMagenta = getCSSVar("--accent-magenta", "255, 87, 179");
  const accentCyan = getCSSVar("--accent-cyan", "74, 210, 255");
  const accentGold = getCSSVar("--accent-gold", "240, 200, 120");

  return createTheme({
    palette: {
      mode,
      primary: {
        main: `rgb(${accentBlue})`,
      },
      secondary: {
        main: `rgb(${accentMagenta})`,
      },
      background: {
        default: `rgb(${bg})`,
        paper: `rgba(${card}, 0.85)`,
      },
      text: {
        primary: `rgb(${text})`,
        secondary: `rgb(${textMuted})`,
      },
      divider: `rgba(${hairline}, ${hairlineOpacity})`,
    },
    shape: {
      borderRadius: 16,
    },
    components: {
      MuiPaper: {
        styleOverrides: {
          root: {
            backgroundImage: "none",
            backdropFilter: "blur(14px)",
            border: `1px solid rgba(${hairline}, ${hairlineOpacity})`,
            boxShadow: `0 14px 44px rgba(${shadow}, ${shadowOpacity}), inset 0 1px 0 rgba(${hairline}, 0.06)`,
            backgroundColor: `rgba(${card}, 0.85)`,
          },
        },
      },
      MuiTextField: {
        styleOverrides: {
          root: {
            "& .MuiOutlinedInput-root": {
              borderRadius: 16,
              "& fieldset": {
                borderColor: `rgba(${hairline}, ${hairlineOpacity})`,
                borderWidth: 1,
              },
              "&:hover fieldset": {
                borderColor: `rgba(${hairline}, ${parseFloat(hairlineOpacity) * 1.67})`,
              },
              "&.Mui-focused fieldset": {
                borderColor: `rgba(${accentCyan}, 0.6)`,
              },
            },
            "& .MuiInputBase-input": {
              color: `rgb(${text})`,
            },
            "& .MuiInputLabel-root": {
              color: `rgb(${textMuted})`,
            },
          },
        },
      },
      MuiTable: {
        styleOverrides: {
          root: {
            borderRadius: 16,
            overflow: "hidden",
            "& .MuiTableHead-root": {
              "& .MuiTableCell-root": {
                backgroundColor: `rgba(${hairline}, ${parseFloat(hairlineOpacity) * 0.25})`,
                borderColor: `rgba(${hairline}, ${hairlineOpacity})`,
                color: `rgba(${accentGold}, 0.88)`,
                fontWeight: 600,
                textTransform: "uppercase",
                letterSpacing: "0.28em",
                fontSize: "0.75rem",
              },
            },
            "& .MuiTableBody-root": {
              "& .MuiTableCell-root": {
                borderColor: `rgba(${hairline}, ${parseFloat(hairlineOpacity) * 0.67})`,
                color: `rgb(${text})`,
              },
              "& .MuiTableRow-root": {
                "&:hover": {
                  backgroundColor: `rgba(${hairline}, ${parseFloat(hairlineOpacity) * 0.42})`,
                },
              },
            },
          },
        },
      },
      MuiDialog: {
        styleOverrides: {
          paper: {
            borderRadius: 24,
            background: `rgba(${card}, 0.95)`,
            backdropFilter: "blur(20px)",
          },
        },
      },
      MuiButton: {
        styleOverrides: {
          root: {
            borderRadius: 12,
            textTransform: "none",
            fontWeight: 600,
            letterSpacing: "0.04em",
            transition: "all 0.2s ease",
            "&:hover": {
              transform: "translateY(-1px)",
            },
          },
          outlined: {
            borderColor: `rgba(${hairline}, ${hairlineOpacity})`,
            borderWidth: 1,
            "&:hover": {
              borderColor: `rgba(${hairline}, ${parseFloat(hairlineOpacity) * 1.67})`,
              backgroundColor: `rgba(${hairline}, ${parseFloat(hairlineOpacity) * 0.83})`,
            },
          },
        },
      },
      MuiChip: {
        styleOverrides: {
          root: {
            borderRadius: 8,
            backgroundColor: `rgba(${hairline}, ${parseFloat(hairlineOpacity) * 0.67})`,
            border: `1px solid rgba(${hairline}, ${hairlineOpacity})`,
            "&:hover": {
              backgroundColor: `rgba(${hairline}, ${hairlineOpacity})`,
            },
          },
        },
      },
      MuiAutocomplete: {
        styleOverrides: {
          root: {
            "& .MuiOutlinedInput-root": {
              borderRadius: 16,
            },
          },
          paper: {
            borderRadius: 16,
            backdropFilter: "blur(14px)",
            background: `rgba(${card}, 0.95)`,
            border: `1px solid rgba(${hairline}, ${hairlineOpacity})`,
          },
        },
      },
    },
  });
};

